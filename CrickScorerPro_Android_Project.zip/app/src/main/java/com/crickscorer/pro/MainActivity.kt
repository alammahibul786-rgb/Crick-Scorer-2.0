package com.crickscorer.pro

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 17, 31)
    private val panel = Color.rgb(18, 34, 52)
    private val green = Color.rgb(0, 230, 160)
    private val white = Color.WHITE
    private var team1 = "HOME"
    private var team2 = "AWAY"
    private var oversLimit = 20
    private var innings = 1
    private var runs = 0
    private var wickets = 0
    private var balls = 0
    private var target = 0
    private var battingFirst = true
    private var striker = 0
    private var nonStriker = 1
    private val batterNames = mutableListOf<String>()
    private val batterRuns = mutableListOf<Int>()
    private val batterBalls = mutableListOf<Int>()
    private val batterOut = mutableListOf<Boolean>()
    private val events = mutableListOf<String>()
    private val undoStack = mutableListOf<JSONObject>()
    private lateinit var root: LinearLayout
    private lateinit var scoreText: TextView
    private lateinit var overText: TextView
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(title: String): LinearLayout {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(bg)
        }
        val sc = ScrollView(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sc.addView(body)
        outer.addView(sc, LinearLayout.LayoutParams(-1, 0, 1f))
        root = body
        text(root, title, 27f, green, true)
        return outer
    }

    private fun text(parent: LinearLayout, value: String, size: Float, color: Int = white, bold: Boolean = false) {
        val t = TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            gravity = Gravity.CENTER; setPadding(5, 8, 5, 8)
            if (bold) setTypeface(null, Typeface.BOLD)
        }
        parent.addView(t, LinearLayout.LayoutParams(-1, -2))
    }

    private fun input(parent: LinearLayout, hint: String, value: String): EditText {
        val e = EditText(this).apply {
            setText(value); this.hint = hint; setTextColor(white); setHintTextColor(Color.LTGRAY)
            textSize = 16f; setSingleLine(true); setPadding(14, 4, 14, 4)
            setBackgroundColor(panel)
        }
        parent.addView(e, LinearLayout.LayoutParams(-1, 54).apply { setMargins(0, 5, 0, 5) })
        return e
    }

    private fun button(parent: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label; textSize = 15f; isAllCaps = false
            setTextColor(white); setBackgroundColor(Color.rgb(0, 125, 91))
            setOnClickListener { action() }
        }
        parent.addView(b, LinearLayout.LayoutParams(-1, 52).apply { setMargins(0, 4, 0, 4) })
    }

    private fun showHome() {
        val view = base("🏏 CRICK SCORER PRO")
        text(root, "PROFESSIONAL MATCH CENTRE", 15f, white, true)
        text(root, "Create a match and keep score ball by ball.", 14f, Color.LTGRAY)
        button(root, "NEW MATCH") { setupMatch() }
        button(root, "RESUME SAVED MATCH") { if (loadMatch()) showScoring() else toast("No saved match found") }
        button(root, "ABOUT") {
            AlertDialog.Builder(this).setTitle("Crick Scorer Pro")
                .setMessage("Version 1.0\\nOffline cricket scoring starter. More features can be added after testing.")
                .setPositiveButton("OK", null).show()
        }
        setContentView(view)
    }

    private fun setupMatch() {
        val view = base("MATCH SETUP")
        val a = input(root, "First team", team1)
        val b = input(root, "Second team", team2)
        val o = input(root, "Overs (1–50)", oversLimit.toString()).apply { inputType = 2 }
        text(root, "Optional: player names are added in a later setup stage.", 13f, Color.LTGRAY)
        button(root, "START MATCH") {
            val av = a.text.toString().trim()
            val bv = b.text.toString().trim()
            val ov = o.text.toString().toIntOrNull()
            if (av.isBlank() || bv.isBlank() || av.equals(bv, true)) {
                toast("Enter two different team names")
            } else if (ov == null || ov !in 1..50) {
                toast("Overs must be between 1 and 50")
            } else {
                team1 = av; team2 = bv; oversLimit = ov
                innings = 1; battingFirst = true; target = 0
                resetInnings()
                showScoring()
            }
        }
        button(root, "BACK") { showHome() }
        setContentView(view)
    }

    private fun resetInnings() {
        runs = 0; wickets = 0; balls = 0; striker = 0; nonStriker = 1
        batterNames.clear(); batterRuns.clear(); batterBalls.clear(); batterOut.clear()
        for (i in 1..11) {
            batterNames.add("Player $i"); batterRuns.add(0); batterBalls.add(0); batterOut.add(false)
        }
        events.clear(); undoStack.clear()
        saveMatch()
    }

    private fun showScoring() {
        val view = base("🏏 LIVE MATCH")
        val batting = if (battingFirst) team1 else team2
        val bowling = if (battingFirst) team2 else team1
        text(root, "$batting  vs  $bowling", 18f, white, true)
        text(root, "INNINGS $innings" + if (target > 0) " • TARGET $target" else " • $oversLimit OVERS", 13f, Color.LTGRAY)
        scoreText = TextView(this).apply {
            textSize = 46f; setTextColor(white); gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD); setPadding(0, 12, 0, 2)
        }
        root.addView(scoreText)
        overText = TextView(this).apply { textSize = 20f; setTextColor(green); gravity = Gravity.CENTER }
        root.addView(overText)
        statusText = TextView(this).apply { textSize = 14f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER }
        root.addView(statusText)
        text(root, "BATTERS", 17f, green, true)
        text(root, "★ ${batterNames[striker]}  ${batterRuns[striker]} (${batterBalls[striker]})", 16f)
        text(root, "${batterNames[nonStriker]}  ${batterRuns[nonStriker]} (${batterBalls[nonStriker]})", 16f)
        text(root, "ADD RUNS", 16f, green, true)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(0,1,2,3,4,6).forEach { n ->
            val b = Button(this).apply {
                text = n.toString(); textSize = 16f; isAllCaps = false
                setTextColor(white); setBackgroundColor(Color.rgb(0,125,91))
                setOnClickListener { addRuns(n) }
            }
            row.addView(b, LinearLayout.LayoutParams(0, 54, 1f).apply { setMargins(2,3,2,3) })
        }
        root.addView(row)
        text(root, "EXTRAS & WICKET", 16f, green, true)
        button(root, "WIDE +1") { addExtra("WD", 1, false) }
        button(root, "NO BALL +1") { addExtra("NB", 1, false) }
        button(root, "BYE +1") { addExtra("B", 1, true) }
        button(root, "LEG-BYE +1") { addExtra("LB", 1, true) }
        button(root, "WICKET") { addWicket() }
        button(root, "CHANGE STRIKE") { swapStrike(); saveMatch(); showScoring() }
        button(root, "UNDO LAST BALL") { undo() }
        button(root, "FULL SCORECARD") { showScorecard() }
        button(root, "END INNINGS / RESULT") { endInnings() }
        button(root, "SAVE MATCH") { saveMatch(); toast("Match saved on this device") }
        button(root, "HOME") { showHome() }
        updateScore()
        setContentView(view)
    }

    private fun snapshot() {
        undoStack.add(JSONObject().apply {
            put("runs", runs); put("wickets", wickets); put("balls", balls)
            put("striker", striker); put("nonStriker", nonStriker)
            val rr = JSONArray(); batterRuns.forEach { rr.put(it) }; put("br", rr)
            val bb = JSONArray(); batterBalls.forEach { bb.put(it) }; put("bb", bb)
            val oo = JSONArray(); batterOut.forEach { oo.put(it) }; put("bo", oo)
            val ev = JSONArray(); events.forEach { ev.put(it) }; put("events", ev)
        })
    }

    private fun addRuns(n: Int) {
        if (inningsOver()) return
        snapshot()
        runs += n; batterRuns[striker] += n; batterBalls[striker]++
        balls++; events.add(n.toString())
        if (n % 2 == 1) swapStrike()
        if (balls % 6 == 0) swapStrike()
        afterDelivery()
    }

    private fun addExtra(code: String, amount: Int, legal: Boolean) {
        if (inningsOver()) return
        snapshot()
        runs += amount
        events.add(code)
        if (legal) {
            balls++
            if (balls % 6 == 0) swapStrike()
            swapStrike()
        }
        afterDelivery()
    }

    private fun addWicket() {
        if (inningsOver()) return
        snapshot()
        wickets++
        batterBalls[striker]++
        batterOut[striker] = true
        balls++; events.add("W")
        val next = (0 until 11).firstOrNull { !batterOut[it] && it != striker && it != nonStriker }
        if (next != null && wickets < 10) striker = next
        if (balls % 6 == 0) swapStrike()
        afterDelivery()
    }

    private fun afterDelivery() {
        saveMatch()
        if (inningsOver()) {
            AlertDialog.Builder(this).setTitle("Innings complete")
                .setMessage(if (innings == 1) "First innings: $runs/$wickets. Start the chase?" else "Chase finished: $runs/$wickets.")
                .setPositiveButton(if (innings == 1) "START CHASE" else "MATCH RESULT") { _, _ -> endInnings() }
                .setNegativeButton("VIEW SCORE", null).show()
        } else showScoring()
    }

    private fun inningsOver(): Boolean =
        wickets >= 10 || balls >= oversLimit * 6 || (innings == 2 && target > 0 && runs >= target)

    private fun swapStrike() { val t = striker; striker = nonStriker; nonStriker = t }

    private fun undo() {
        if (undoStack.isEmpty()) { toast("Nothing to undo"); return }
        val s = undoStack.removeAt(undoStack.lastIndex)
        runs = s.getInt("runs"); wickets = s.getInt("wickets"); balls = s.getInt("balls")
        striker = s.getInt("striker"); nonStriker = s.getInt("nonStriker")
        val rr = s.getJSONArray("br"); val bb = s.getJSONArray("bb"); val oo = s.getJSONArray("bo")
        for (i in 0 until 11) { batterRuns[i] = rr.getInt(i); batterBalls[i] = bb.getInt(i); batterOut[i] = oo.getBoolean(i) }
        events.clear(); val ev = s.getJSONArray("events"); for (i in 0 until ev.length()) events.add(ev.getString(i))
        saveMatch(); showScoring()
    }

    private fun endInnings() {
        if (innings == 1) {
            target = runs + 1
            innings = 2; battingFirst = false
            resetInnings(); showScoring()
        } else {
            val result = when {
                runs >= target -> "$team2 won by ${10 - wickets} wickets"
                runs == target - 1 -> "Match tied"
                else -> "$team1 won by ${target - runs - 1} runs"
            }
            AlertDialog.Builder(this).setTitle("MATCH RESULT")
                .setMessage("$team1 first innings target: $target\\n$team2: $runs/$wickets\\n\\n$result")
                .setPositiveButton("HOME") { _, _ -> showHome() }
                .setNeutralButton("SCORECARD") { _, _ -> showScorecard() }.show()
        }
    }

    private fun showScorecard() {
        val view = base("FULL SCORECARD")
        text(root, "${if (battingFirst) team1 else team2}: $runs/$wickets", 22f, green, true)
        text(root, "Overs: ${overTextValue()}   Run rate: ${String.format(Locale.US, "%.2f", if (balls == 0) 0.0 else runs * 6.0 / balls)}", 14f, Color.LTGRAY)
        text(root, "BATTER                         R (B)", 14f, green, true)
        for (i in 0..10) text(root, "${batterNames[i]}   ${if (batterOut[i]) "out" else "not out"}   ${batterRuns[i]} (${batterBalls[i]})", 14f)
        text(root, "BALL-BY-BALL", 16f, green, true)
        text(root, events.joinToString("  ").ifBlank { "No deliveries yet" }, 14f)
        button(root, "BACK TO LIVE SCORING") { showScoring() }
        button(root, "HOME") { showHome() }
        setContentView(view)
    }

    private fun updateScore() {
        scoreText.text = "$runs / $wickets"
        overText.text = "OVERS  ${overTextValue()}"
        statusText.text = if (innings == 2) "NEED ${maxOf(0, target-runs)} RUNS • ${maxOf(0, oversLimit*6-balls)} BALLS LEFT" else "RUN RATE  ${String.format(Locale.US, "%.2f", if (balls == 0) 0.0 else runs*6.0/balls)}"
    }

    private fun overTextValue() = "${balls / 6}.${balls % 6}"

    private fun saveMatch() {
        val p = getSharedPreferences("match", Context.MODE_PRIVATE)
        val j = JSONObject().apply {
            put("team1", team1); put("team2", team2); put("overs", oversLimit)
            put("innings", innings); put("runs", runs); put("wickets", wickets)
            put("balls", balls); put("target", target); put("battingFirst", battingFirst)
            put("striker", striker); put("nonStriker", nonStriker)
            fun ints(values: List<Int>) = JSONArray().also { a -> values.forEach { a.put(it) } }
            fun bools(values: List<Boolean>) = JSONArray().also { a -> values.forEach { a.put(it) } }
            put("names", JSONArray(batterNames)); put("br", ints(batterRuns)); put("bb", ints(batterBalls)); put("bo", bools(batterOut))
            put("events", JSONArray(events))
        }
        p.edit().putString("data", j.toString()).apply()
    }

    private fun loadMatch(): Boolean {
        return try {
            val raw = getSharedPreferences("match", Context.MODE_PRIVATE).getString("data", null) ?: return false
            val j = JSONObject(raw)
            team1 = j.getString("team1"); team2 = j.getString("team2"); oversLimit = j.getInt("overs")
            innings = j.getInt("innings"); runs = j.getInt("runs"); wickets = j.getInt("wickets")
            balls = j.getInt("balls"); target = j.getInt("target"); battingFirst = j.getBoolean("battingFirst")
            striker = j.getInt("striker"); nonStriker = j.getInt("nonStriker")
            batterNames.clear(); batterRuns.clear(); batterBalls.clear(); batterOut.clear(); events.clear()
            val nn=j.getJSONArray("names"); val rr=j.getJSONArray("br"); val bb=j.getJSONArray("bb"); val oo=j.getJSONArray("bo"); val ev=j.getJSONArray("events")
            for(i in 0 until nn.length()) batterNames.add(nn.getString(i))
            for(i in 0 until rr.length()) batterRuns.add(rr.getInt(i))
            for(i in 0 until bb.length()) batterBalls.add(bb.getInt(i))
            for(i in 0 until oo.length()) batterOut.add(oo.getBoolean(i))
            for(i in 0 until ev.length()) events.add(ev.getString(i))
            undoStack.clear()
            true
        } catch (_: Exception) { false }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
