CRICK SCORER PRO — Android starter project

WHAT IS INCLUDED
- Native Android Kotlin project
- Dark navy / green interface
- New match setup
- Ball-by-ball runs, wides, no-balls, byes, leg-byes and wickets
- Strike changes, overs, run rate, undo
- Basic scorecard
- Local save/resume on the same device

BUILD NOTES
This is the source project, not a precompiled APK.
To build on an Android phone, open/import this folder in an Android IDE that supports
Gradle Android projects (for example AndroidIDE), allow Gradle sync, then build the
debug APK from the IDE's Build menu.

Project requirements:
- Android Gradle Plugin 8.7.3
- Kotlin Android plugin 2.0.21
- compileSdk 35
- minSdk 23

Please test scoring carefully before using it for an official match. This is version 1.0
and does not yet include full bowling figures, dismissal selection, tournament tables,
cloud sync, or multi-match history.
